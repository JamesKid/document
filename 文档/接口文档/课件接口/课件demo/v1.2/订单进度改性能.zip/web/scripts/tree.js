﻿function TreeNode(id, name, icon, href, target)
{
	this.id = id;
	this.name = name;
	this.icon = icon;
	this.href = href;
	this.target = target;
	this.parent = null;
	this.children = [];
}

TreeNode.prototype.find = function(id)
{
	for (var i = 0, n = this.children.length; i < n; i++)
	{
		var child = this.children[i];
		if (child.id == id)
			return child;
		else
		{
			var node = child.find(id);
			if (node != null)
				return node;
		}
	}
	return null;
}

TreeNode.prototype.add = function(node)
{
	this.children.push(node);
	node.parent = this;
}



function TreeView(rootNode)
{
	this.rootItem = new TreeViewItem(rootNode);
}

TreeView.prototype.create = function(parentElement)
{
	var olElement = document.createElement("ol");
	olElement.className = "treeview";
	this.rootItem.create(olElement);
	parentElement.appendChild(olElement);
}

TreeView.prototype.find = function(node)
{
	if (this.rootItem == null)
		return null;
	else if (this.rootItem.node == node)
		return this.rootItem;
	else
		return this.rootItem.find(node);
}


function TreeViewItem(node)
{
	// Members
	this.node = node;
	this.items = [];
	this.isGroup = (node.children.length > 0);
	this.isRoot = (node.parent == null);
	this.isExpanded = this.isRoot;
	
	// Initialize sub items
	for (var i = 0, n = node.children.length; i < n; i++)
		this.items.push( new TreeViewItem(node.children[i]) );
	
	// Html elements
	this.liElement = null;
	this.olElement = null;
}

TreeViewItem.prototype.create = function(parentElement)
{
	// Get a pointer to the current instance
	var instance = this;
	
	// Create the list item and make it clickable
	this.liElement = document.createElement("li");
	this.liElement.className = "item";
	if (this.isRoot)
		this.liElement.className += " root ";
	if (this.isGroup)
	{
		this.liElement.className += " group ";
		this.liElement.className += this.isExpanded ? " expanded " : " collapsed ";
		
		// Collapse or expand the group when clicked (not available at root level)
		if (!this.isRoot)
		{
			this.liElement.onclick = function()
			{
				instance.toggle();
				
				if (!e) var e = window.event;
				e.cancelBubble = true;
				if (e.stopPropagation) e.stopPropagation();
			};
		}
	}
	
	// Create the link containing the icon and the name of the node
	var linkElement = document.createElement("a");
	linkElement.className = "link";
	linkElement.href = this.node.href;
	if (this.node.target)
		linkElement.target = this.node.target;
	
	// Create the icon of the node
	var iconElement = document.createElement("img");
	iconElement.className = "icon";
	if (this.node.icon)
	{
		iconElement.src = this.node.icon;
	}
	else
	{
		iconElement.src = "images/empty.gif"; // TODO: put the string "images/empty.gif" in a variable
		iconElement.className += " default ";
	}
	iconElement.alt = "";
	linkElement.appendChild(iconElement);
	
	// Create the text element containing the name of the node
	var textElement = document.createElement("span");
	textElement.innerHTML = unescape(this.node.name);
	linkElement.appendChild(textElement);
	
	// Add the link to the item
	this.liElement.appendChild(linkElement);
	
	// Add the item item to the treeview
	parentElement.appendChild(this.liElement);
	
	// Create the group containing the child items
	if (this.isGroup)
	{
		this.olElement = document.createElement("ol");
		this.olElement.className = "group";
		this.olElement.style.display = this.isExpanded ? "" : "none";
		
		for (var i = 0, n = this.items.length; i < n; i++)
			this.items[i].create(this.olElement);
			
		parentElement.appendChild(this.olElement);
	}
}

TreeViewItem.prototype.toggle = function()
{
	if (this.isExpanded)
		this.collapse();
	else
		this.expand();
}

TreeViewItem.prototype.collapse = function()
{
	if (this.isExpanded)
	{
		this.liElement.className = this.liElement.className.replace(" expanded ","");
		this.liElement.className += " collapsed "; 
		
		if (this.olElement)
			this.olElement.style.display = "none";
		
		this.isExpanded = false;
	}
}

TreeViewItem.prototype.expand = function()
{
	if (!this.isExpanded)
	{
		this.liElement.className = this.liElement.className.replace(" collapsed ","");
		this.liElement.className += " expanded "; 
		
		if (this.olElement)
			this.olElement.style.display = "";
		
		this.isExpanded = true;
	}
}

TreeViewItem.prototype.show = function()
{
	this.liElement.style.display = "";
	if (this.olElement)
		this.olElement.style.display = this.isExpanded ? "" : "none";
}

TreeViewItem.prototype.hide = function()
{
	this.liElement.style.display = "none";
	if (this.olElement)
		this.olElement.style.display = "none";
}

TreeViewItem.prototype.find = function(node)
{
	for (var i = 0, n = this.items.length; i < n; i++)
	{
		var item = this.items[i];
		if (item.node == node)
			return item;
		else
		{
			var foundItem = item.find(node);
			if (foundItem != null)
				return foundItem;
		}
	}
	return null;
}