﻿// Replace / by \\ and encode path
function GetFilename(path)
{
	var pos=path.lastIndexOf("\\");
	var pos2=path.lastIndexOf("/");
	
	if (pos<pos2) pos=pos2;

	if (pos==-1)
		return path;
	else 
		return path.substring(pos+1,path.length);

}

function GetParentDirectory(path,level)
{
	var sDir=path;
	
	/* Remove the eventual parameters. */
	var iParams = sDir.indexOf('?');
	if (iParams != -1)
		sDir = sDir.substring(0, iParams);
	
	/* Get the parent directory, stopping at the requested level. */
	for(var i=0; i<level; i++) 
	{
		sDir = sDir.substring(0, sDir.lastIndexOf("/",sDir.length-2) + 1);
	}
	
	return sDir;
}
