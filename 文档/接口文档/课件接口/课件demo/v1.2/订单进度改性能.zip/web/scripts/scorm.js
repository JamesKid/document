﻿/***************************************************************************
 *Copyright (C) 2008 Assima Ltd. All Rights Reserved.
 *
 * PROJECT:		SCORM
 * MODULE:		JAVASCRIPT
 * DESCRIPTION: Scorm Javascript file
 * WRITTEN BY:	
 * HISTORY:
 *  This file contains all the functions used to ensure Scorm communications.
 *  Reviewed to allow resuming lesson using ATS 6
 ***************************************************************************/

/**SCORM CONSTANTS*/
var _SCORM_LESSON_STATUS		= "cmi.core.lesson_status";
var _SCORM_LESSON_LOCATION		= "cmi.core.lesson_location";
var _SCORM_ENTRY				= "cmi.core.entry";
var _SCORM_EXIT					= "cmi.core.exit";
var _SCORM_SUSPEND_DATA			= "cmi.core.suspend_data";
var _SCORM_STUDENT_ID			= "cmi.core.student_id";
var _SCORM_STUDENT_NAME			= "cmi.core.student_name";
var _SCORM_CREDIT				= "cmi.core.credit";
var _SCORM_SCORE_RAW			= "cmi.core.score.raw";
var _SCORM_SCORE_MAX			= "cmi.core.score.max";
var _SCORM_SCORE_MIN			= "cmi.core.score.min";
var _SCORM_TIME_TOTAL			= "cmi.core.total_time";
var _SCORM_SESSION_TIME			= "cmi.core.session_time";
var _SCORM_MASTERY_SCORE		= "cmi.student_data.mastery_score";

var _SCORM_STATUS_FAILED		= "failed";
var _SCORM_STATUS_INCOMPLETE	= "incomplete";
var _SCORM_STATUS_PASSED		= "passed";
var _SCORM_STATUS_COMPLETED		= "completed";
var _SCORM_ENTRY_INITIAL		= "ab-initio";
var _SCORM_ENTRY_RESUME			= "resume";
var _SCORM_EXIT_SUSPEND			= "suspend";

/** Types of score. */
var _SCORE_TYPE_UNDEFINED		= null;
var _SCORE_TYPE_DEFAULT			= 0;
var _SCORE_TYPE_CUSTOM			= 1;

/** Enable debugging. **/
var _LmsDebug = false;

/***************************************************************************
*														*
*		THIS IS THE SCORM COMMUNICATION IMPLEMENTATION PART	*
*														*
****************************************************************************/

/**Function that initializes SCORM*/
function DoInitializeSCORM()
{
	/*** Check if we need to initialize. */
	if (!window.oSCORM || !window.oSCORM.init)
	{
		/**Initialize*/
		var theResult = doLMSInitialize();
		
		/**Check the initialization has been successfull*/
		if(theResult == true || theResult == "true")
		{
			/**create a SCORM object to store info*/
			window.oSCORM = new Object();
			
			/**Get SCORM INFO*/
			window.oSCORM.student_id	= doLMSGetValue(_SCORM_STUDENT_ID);
			window.oSCORM.student_name	= doLMSGetValue(_SCORM_STUDENT_NAME);
			window.oSCORM.credit		= doLMSGetValue(_SCORM_CREDIT);
			window.oSCORM.lesson_status	= doLMSGetValue(_SCORM_LESSON_STATUS);
			window.oSCORM.score_raw		= doLMSGetValue(_SCORM_SCORE_RAW);
			window.oSCORM.total_time	= doLMSGetValue(_SCORM_TIME_TOTAL);
			window.oSCORM.mastery_score	= doLMSGetValue(_SCORM_MASTERY_SCORE);
			window.oSCORM.entry_status	= doLMSGetValue(_SCORM_ENTRY);
			window.oSCORM.location		= doLMSGetValue(_SCORM_LESSON_LOCATION);
			
			/**
			*RTC fix
			*/
			/**If we don't receive any max value set it at 100*/
			window.oSCORM.score_max		= doLMSGetValue(_SCORM_SCORE_MAX);
			if(window.oSCORM.score_max == "")
				window.oSCORM.score_max = 100;
			
			/**If we don't receive any min value set it at 0*/
			window.oSCORM.score_min		= doLMSGetValue(_SCORM_SCORE_MIN);
			if(window.oSCORM.score_min == "")
				window.oSCORM.score_min = 0;
			/**End of RTC fix*/
			
			/**Mark oSCORM as initialized*/
			window.oSCORM.init = true;
		}
	}
	
	/*** Launch the lesson if scorm is initialized properly. */
	if (window.oSCORM && window.oSCORM.init)
	{
		/** Initialize the entry state. */
		g_nResumeAction = _NO_RESUME;
		
		/** For now, we are only able to resume lessons launched in default score mode. */
		if (g_bAllowResuming && (g_nScoreType == _SCORE_TYPE_DEFAULT || g_nScoreType == _SCORE_TYPE_UNDEFINED))
		{
			/**Can this simulation be resumed?*/
			//if(theEntryStatus == _SCORM_ENTRY_RESUME) // COMMENTED: Some LMS return an empty string when a lesson must be resumed
			// Make sure the entry status is not empty either: "neither an initial launch (ab-initio) nor a continuation from a suspended state (resume)" (#15437)
			if (window.oSCORM.entry_status != _SCORM_ENTRY_INITIAL && window.oSCORM.entry_status != null) 
			{
				/**We have to parse the string to get the different information, store parameters in an array*/
				if (window.oSCORM.location.length > 0) // [#17345] Make sure the resume location is valid
				{
					var ParamArray = window.oSCORM.location.split(";");
					
					/**Get the resuming parameters*/
					g_nPreviousSteps = (ParamArray.length > 0) ? ParamArray[0] : null;			// Previous number of steps that were completed
					g_nPreviousScore = (ParamArray.length > 1) ? ParamArray[1] : null;			// Previous score on last session
					g_nResumeAction  = (ParamArray.length > 2) ? ParamArray[2] : _NO_RESUME;	// TutAction id, where the lesson must be resumed
				}
			}
		}
		
		/** Notify we are launching the lesson, and eventually launch it if the event was not processed. */
		if (!window.OnLaunch || !OnLaunch(g_nResumeAction))
			Launch(g_nResumeAction);
	}
	else
	{
		/* Failed to initialize. */
		return 0;
	}
}

/**Function that sends scores and terminates SCORM*/
function DoTerminateSCORM(nScore, nCompletedSteps, nTotalStep, strSessionTime, nResumeAction)
{
	/* Test for the SCORM API Wrapper. */
	if (!window.oSCORM || window.oSCORM.init==false)
		return 0;
	
	/* Stop any other SCORM from Processing. */
	window.oSCORM.init = false;
	
	/* Normalize the values passed in parameter. */
	nScore 			= (typeof(nScore) != "number") ? parseInt(nScore) : nScore;
	nCompletedSteps	= (typeof(nCompletedSteps) != "number") ? parseInt(nCompletedSteps) : nCompletedSteps;
	nTotalStep		= (typeof(nTotalStep) != "number") ? parseInt(nTotalStep) : nTotalStep;
	
	/* Calculate the number of step completed in the lesson so far. */
	if (g_nPreviousSteps != null)
		nCompletedSteps += parseInt(g_nPreviousSteps);
	
	/* Calculate the overall score on the lesson so far. */
	if (g_nPreviousScore != null)
		nScore += parseInt(g_nPreviousScore);
	
	/** Was the lesson stopped on an action that will require resuming later? */
	if (nResumeAction != _NO_RESUME)
	{
		/* Remember that the user has not finished the lesson*/
		if (g_bSendCompletionStatus)
		{
			if (_LmsDebug) alert("_SCORM_LESSON_STATUS: _SCORM_STATUS_INCOMPLETE");
			doLMSSetValue(_SCORM_LESSON_STATUS, _SCORM_STATUS_INCOMPLETE);
		}
		
		/* Set the exit state to suspended. */
		if (_LmsDebug) alert("_SCORM_EXIT: _SCORM_EXIT_SUSPEND");
		doLMSSetValue(_SCORM_EXIT, _SCORM_EXIT_SUSPEND);
		
		/* Save the exit point, so the user will get back there next time. */
		if (_LmsDebug) alert("(_SCORM_LESSON_LOCATION: " + nCompletedSteps + ";" + nScore + ";" + nResumeAction);
		doLMSSetValue(_SCORM_LESSON_LOCATION, nCompletedSteps + ";" + nScore + ";" + nResumeAction);
		
		/* Only send score for unfinished lesson if not in credit mode. */
		if (g_bSendScore && window.oSCORM.credit != "credit")
		{
			if (_LmsDebug) alert("_SCORM_SCORE_RAW: " + 0);
			doLMSSetValue(_SCORM_SCORE_RAW, 0);
		}
	}
	/** Is the lesson finished? */
	else
	{
		/* Compute the average score if in default score mode. */
		if (g_nScoreType == _SCORE_TYPE_DEFAULT || g_nScoreType == _SCORE_TYPE_UNDEFINED)
		{
			if (nCompletedSteps != 0)
				nScore = nScore / nCompletedSteps;
		}
		
		/* Convert the score into a SCORM percentage */
		if (g_nScoreMax != null && g_nScoreMax != 0)
			nScore = Math.round(nScore * 100 / g_nScoreMax);
		else
			nScore = Math.round(nScore);
		
		/*Set the score. */
		if (g_bSendScore)
		{
			if (_LmsDebug) alert("_SCORM_SCORE_RAW: " + nScore);
			doLMSSetValue(_SCORM_SCORE_RAW, nScore);
		}
		
		/* Now set the lesson status depending on credit mode and mastery score. */
		if (g_bSendCompletionStatus)
		{
			if (g_bSendSuccessStatus)
			{
				var nMasteryScore = 0;
				if (window.oSCORM.mastery_score != "")
					nMasteryScore = (typeof(window.oSCORM.mastery_score) != "number") ? parseInt(window.oSCORM.mastery_score) : window.oSCORM.mastery_score;
				
				/* Is the current score higher than the mastery one? */
				if (nScore >= nMasteryScore)
				{
					/* Then it's either passed or completed depending on credit mode. */
					if (window.oSCORM.credit == "credit")
					{
						if (_LmsDebug) alert("_SCORM_LESSON_STATUS: _SCORM_STATUS_PASSED");
						doLMSSetValue(_SCORM_LESSON_STATUS, _SCORM_STATUS_PASSED);
					}
					else
					{
						if (_LmsDebug) alert("_SCORM_LESSON_STATUS: _SCORM_STATUS_COMPLETED");
						doLMSSetValue(_SCORM_LESSON_STATUS, _SCORM_STATUS_COMPLETED);
					}
				}
				else
				{
					/* It's failed. */
					if (_LmsDebug) alert("_SCORM_LESSON_STATUS: _SCORM_STATUS_FAILED");
					doLMSSetValue(_SCORM_LESSON_STATUS, _SCORM_STATUS_FAILED);
				}
			}
			else
			{
				/* Do not tell the server if the user succeeded or not; only say that the lesson has been completed. */
				if (_LmsDebug) alert("_SCORM_LESSON_STATUS: _SCORM_STATUS_COMPLETED");
				doLMSSetValue(_SCORM_LESSON_STATUS, _SCORM_STATUS_COMPLETED);
			}
		}
		
 		/* [#17345] Reset the lesson location as the user completed the lesson (some LMS don't do it automatically). */
		doLMSSetValue(_SCORM_LESSON_LOCATION, "");
	}
	
	/* Set the score max. */
	if (_LmsDebug) alert("_SCORM_SCORE_MAX: " + window.oSCORM.score_max);
	doLMSSetValue(_SCORM_SCORE_MAX, window.oSCORM.score_max);
	
	/* Set the score min. */
	if (_LmsDebug) alert("_SCORM_SCORE_MIN: " + window.oSCORM.score_min);
	doLMSSetValue(_SCORM_SCORE_MIN, window.oSCORM.score_min);
	
	/* Set the session time. */
	if (g_bSendDuration)
	{
		if (_LmsDebug) alert("_SCORM_SESSION_TIME: " + strSessionTime);
		doLMSSetValue(_SCORM_SESSION_TIME, strSessionTime);
	}
	
	/* Commit all the result. */
	doLMSCommit();
	
	/* Terminate SCORM. */
	doLMSFinish();
}