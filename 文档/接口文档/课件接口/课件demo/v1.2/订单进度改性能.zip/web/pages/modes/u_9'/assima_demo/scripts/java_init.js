﻿/****** Load the Java Applet using Java Plug-in (see http://java.sun.com/javase/6/docs/technotes/guides/plugin/developer_guide/using_tags.html) *******/
var sAppletElement = "";

if (navigator.appName == 'Microsoft Internet Explorer') 
{
	sAppletElement  = '<OBJECT ';
	sAppletElement += ' classid="clsid:8AD9C840-044E-11D1-B3E9-00805F499D93"';
	sAppletElement += ' codebase="http://java.sun.com/update/1.6.0/jinstall-6-windows-i586.cab"';
	sAppletElement += ' id="JavaLoader"';
	sAppletElement += ' width="0"';
	sAppletElement += ' height="0"';
	sAppletElement += ' style="position: absolute"';
	sAppletElement += '>';
	sAppletElement += ' <PARAM name="archive" value="../../../../../javaloader/deployer.jar,../../../../../javaloader/deployernativelib.jar">';
	sAppletElement += ' <PARAM name="code" value="assima.deployer.Deployer.class">';
	sAppletElement += '</OBJECT>';
}
else if (navigator.appName == 'Opera')
{
	sAppletElement  = "<APPLET";
	sAppletElement += "	ARCHIVE  = \"../../../../../javaloader/deployer.jar,../../../../../javaloader/deployernativelib.jar\"";
	sAppletElement += "	CODEBASE = \".\"";
	sAppletElement += "	CODE     = \"assima.deployer.Deployer.class\"";
	sAppletElement += "	NAME     = \"JavaLoader\"";
	sAppletElement += "	WIDTH    = \"0\"";
	sAppletElement += "	HEIGHT   = \"0\"";
	sAppletElement += "	ID		 = \"JavaLoader\"";
	sAppletElement += "	MAYSCRIPT= \"true\"";
	sAppletElement += "	VIEWASTEXT = \"true\"";
	sAppletElement += "	STYLE = \"position: absolute\">";
	sAppletElement += "您的窗口不支持Java……";
	sAppletElement += "</APPLET>";
}
else
{
	sAppletElement  = '<embed type="application/x-java-applet;version=1.3"';
	sAppletElement += ' id="JavaLoader"';
	sAppletElement += ' archive="../../../../../javaloader/deployer.jar,../../../../../javaloader/deployernativelib.jar"';
	sAppletElement += ' code="assima.deployer.Deployer.class"';
	sAppletElement += ' pluginspage="http://java.com"';
	sAppletElement += ' mayscript="true"';
	sAppletElement += ' width="0"';
	sAppletElement += ' height="0"';
	sAppletElement += ' style="position: absolute"';
	sAppletElement += '>';
}

/* Insert object. */
document.write(sAppletElement);