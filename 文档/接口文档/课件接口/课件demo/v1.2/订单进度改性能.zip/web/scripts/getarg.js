﻿// Get Argument from Url
function getValArg(sUrl,arg)
{
   
var r=sUrl.toUpperCase().indexOf(arg.toUpperCase()+"=");
if (r==-1) 
 	return null;
 
if(sUrl.substring(r-1,r)=="&"||sUrl.charAt(r-1)=="?")
{
    var ss = sUrl.substring(r+arg.length+1, sUrl.length);
    var pos = ss.indexOf("&");
    if (pos>=0)
    {
      ss =ss.substring(0,pos);
    } 
    
    return ss;
}
return "";

}

function GetAllArg(sUrl)
{
   
var r=sUrl.indexOf("?");
if (r==-1) 
 	return "";

var ss = sUrl.substring(r,sUrl.length);
    
return ss;

}

/**********************************************
* NAME: CreateUrlParam
* DESC: Create Parameter for URL from an array 
* first row: Parameter's name
* second row: Parameter's value
*************************************************/
function CreateUrlParam(aParam)
{
   
	var firstParam=true;
	var sUrlParam="";

	for (index=0;index<aParam.length;index+=2)
	{

		if (aParam[index] && aParam[index+1])
		{
			if (firstParam)
			{
				sUrlParam="?";
				firstParam=false;
			}
			else 
				sUrlParam+="&";

				sUrlParam+=aParam[index]+"=";
				sUrlParam+=aParam[index+1];
		}
	}

	return sUrlParam;

}



