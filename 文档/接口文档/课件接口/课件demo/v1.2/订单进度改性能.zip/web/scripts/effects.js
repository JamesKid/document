﻿/***************************************************************************
 *Copyright (C) 2007 Assima Ltd. All Rights Reserved.
 *
 * PROJECT:		Training Portal
 * MODULE:		JAVASCRIPT
 * DESCRIPTION: Dragging DIV
 * WRITTEN BY:	P.Boivent
 * HISTORY:
 *   Creation 05th January 2007
 ***************************************************************************/
 
 
/***************************************************************************
****************************************************************************
**
** SECTION NAME:	T H E		D R A G G I N G			O B J E C T
**
****************************************************************************/

var dragobject=
	{
	/************************************
	*	The dragging object members
	************************************/

	z: 0,
	x: 0,
	y: 0,
	offsetx : null,
	offsety : null,
	targetobj : null, 
	dragapproved : 0,
	
	/*********************************************
	*	The dragging object initialize function
	**********************************************/
	initialize:function()
		{
		//alert("init");
		/**Begin drag on mousedown*/
		document.onmousedown=this.drag;
		/**End the drag on mouse up*/
		document.onmouseup=function(){this.dragapproved=0};
		},

	/***********************************
	*	The dragging object methods
	***********************************/
	drag:function(e)
		{
		/**Get window event object*/
		var evtobj=window.event? window.event : e;
		this.targetobj=window.event? event.srcElement : e.target;
		//alert(this.targetobj.className);
		/**Check the event source is a draggable object*/
		if (this.targetobj.className=="drag")
			{
			//alert(this.targetobj.id);
			
			//recurse to find the object to dragg
			var theParent = this.targetobj;
			while(theParent.parentElement != null && theParent.parentElement.className == "drag")
				{
				/**Recurse on the parent*/
				theParent = theParent.parentElement;
				}
			
			/**Save the object to dragg*/
			this.targetobj = theParent;
			//alert(this.targetobj.id);

			/**enable the object moves*/
			this.dragapproved=1
			
			if (isNaN(parseInt(this.targetobj.style.left)))
				this.targetobj.style.left=0;
			if (isNaN(parseInt(this.targetobj.style.top)))
				this.targetobj.style.top=0;
			this.offsetx=parseInt(this.targetobj.style.left);
			this.offsety=parseInt(this.targetobj.style.top);
			this.x=evtobj.clientX;
			this.y=evtobj.clientY;
			if (evtobj.preventDefault)
				evtobj.preventDefault();
			
			/**Move the object whilst mouse moving*/
			document.onmousemove=dragobject.moveit
			}
		},
		
	moveit:function(e)
		{
		//alert();
		/**Get window event object*/
		var evtobj=window.event? window.event : e;
		
		/**Is drag is approved?*/
		if (this.dragapproved==1)
			{
			this.targetobj.style.left=this.offsetx+evtobj.clientX-this.x+"px";
			this.targetobj.style.top=this.offsety+evtobj.clientY-this.y+"px";
			return false;
			}
		}
	}