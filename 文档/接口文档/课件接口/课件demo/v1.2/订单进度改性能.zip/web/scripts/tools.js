﻿// Defining a few global variables to keep things simpler and to avoid complications
var HexChars = "0123456789ABCDEF";

// Created by T.N.W.Hynes - (c) 2002 PalandorZone.com ... Use it freely but leave this line intact
// Conversion function for Hexadecimal to Decimal - FF max
function Hex2Dec(HexVal){
HexVal=HexVal.toUpperCase();
var DecVal=0;
var HV1=HexVal.substring(0,1);
DecVal=(HexChars.indexOf(HV1)*16);
HV1=HexVal.substring(1);
DecVal+=HexChars.indexOf(HV1);
return DecVal;
}

// Created by T.N.W.Hynes - (c) 2002 PalandorZone.com ... Use it freely but leave this line intact
// Conversion function for Decimal to Hexadecimal - 255 max
function Dec2Hex(DecVal){
DecVal=parseInt(DecVal);
if (DecVal > 255 || DecVal < 0){
DecVal=255;
}
var Dig1 = DecVal % 16;
var Dig2 = (DecVal-Dig1) / 16;
var HexVal = HexChars.charAt(Dig2)+HexChars.charAt(Dig1);
return HexVal;
}


// Replace / by \\ and encode path
function CreatePathWin(path)
{
var pathWin="";
for(i=0;i<path.length;i++)
{
	switch (path.charAt(i)) 
	{ 
   		case "/" : 
 	    	pathWin=pathWin+"\\";
    		break; 
   		case "%" : 
	 	    	var ch="";
	 	       	ch=String.fromCharCode(Hex2Dec(""+path.charAt(i+1)+path.charAt(i+2)));
	 	       	pathWin=pathWin+ch;
	 		i=i+2;   		
    		break; 
   		default: 
	      	pathWin=pathWin+path.charAt(i);
		break;
	} 
}
return pathWin;
}


// Decode text
function Decode(text)
{
var textResult="";

if (text=="")
return "";

for(i=0;i<text.length;i++)
	{
	switch (text.charAt(i)) 
		{ 
	      		case "%" : 
		 	    	var ch="";
		 	       	ch=String.fromCharCode(Hex2Dec(""+text.charAt(i+1)+text.charAt(i+2)));
		 	       	textResult=textResult+ch;
		 		i=i+2;   		
	    		 //document.write(textResult);
	    		break; 
	   		default: 
			      	textResult=textResult+text.charAt(i);
			break;
		} 
	}
return textResult;
}

// Encode text
function Encode(text,ch)
{
var textResult="";

if (text=="")
	return "";

for(i=0;i<text.length;i++)
	{
	switch (text.charAt(i)) 
		{ 
	      		case ch : 
	 	     //  	ch=String.fromCharCode(Hex2Dec(""+text.charAt(i+1)+text.charAt(i+2)));
		 	       	textResult=textResult+"%"+Dec2Hex(text.charCodeAt(i));
	    		break; 
	   		default: 
		      	textResult=textResult+text.charAt(i);
			break;
		} 
	}
return textResult;
}



function AffichHtml(text)
{
var textResult="";
for(i=0;i<text.length;i++)
	{
	switch (text.charAt(i)) 
		{ 
	      		case '<' : 
		 	       	textResult=textResult+"&lt;";
	    		break; 
	    		case '>' : 
		 	       	textResult=textResult+"&gt;";
	    		break; 
	   		default: 
		      	textResult=textResult+text.charAt(i);
			break;
		} 
	}
return textResult;
}


/********************************************
*Description : Functions recursively unescape
* a string till it's wortheless
*********************************************/
function UnescapeRec(StrEscaped)
{
	var size = StrEscaped.length;
	var StrUnescaped = unescape(StrEscaped);
	while(StrUnescaped.length < size)
	{
		size = StrUnescaped.length;
		StrUnescaped = unescape(StrUnescaped);
	}
	return StrUnescaped;
}


function BooltoChar(bValue)
{
	if (bValue)
		return 'Y';
	else 
		return 'N';
}


function CharToBool(cValue)
{
	if (cValue=='Y'||cValue=='y'||cValue=='yes'||cValue=='Yes'||cValue=='YES'||cValue=='true'||cValue=='True'||cValue=='TRUE'||cValue=='1')
		return true;
	else 
		return false;
}

/** Parse a date confirming to the following format: dd/mm/yyyy. */
/* Note: any separator can be used to separate the digits. */
function ParseDate(strDate)
{
	/* Check if the date matches and retrieve its day, month and year in an array. */
	var arrayDate = strDate.match(/^(\d{2})\D(\d{2})\D(\d{4})$/);
	
	/* If date doesn't respect the expected format, return null. */
	if (!arrayDate)
		return null;
		
	/* Return a new date object (remove 1 to the month: expected [0-11]...). */
	return new Date(arrayDate[3], arrayDate[2] - 1, arrayDate[1]);
}


/********************************************
*	Description : Display attributes objects in alert Box
*
*********************************************/

function DisplayObject(oObject,aAttToDisplay)
		{

			var ListOptions="";
			var val=null;
			
			for (var iCount=0;iCount<aAttToDisplay.length;iCount++)
			{
				
				eval("val=oObject."+aAttToDisplay[iCount]);
				
				if (val!=null)
				{
					ListOptions+=aAttToDisplay[iCount]+"=";
					ListOptions+=val;
				}
				else
				{
					ListOptions+="//"+aAttToDisplay[iCount];
				}
				
				ListOptions+="\n";
			}	

			alert(ListOptions);
}
