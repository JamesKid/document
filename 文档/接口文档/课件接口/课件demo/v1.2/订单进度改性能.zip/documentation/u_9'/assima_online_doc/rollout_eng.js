﻿var bOpen=false;


function SetStepFound(stepFoundValue)
{
	stepFoundTable[stepFoundTable.length-1] = stepFoundValue;
}

function AddElmtStepFound()
{
	stepFoundTable[stepFoundTable.length] = 0;
}


function GetStepFound()
{
	if (stepFoundTable.length>0)
	{
		return stepFoundTable[stepFoundTable.length-1]
	}
}

function RemoveElmtStepFound()
{
	stepFoundTable.pop();
}

function SetScreenNumber(ScreenNumber)
{
	ScreenNumberTable[ScreenNumberTable.length-1] = ScreenNumber;
}

function GetScreenNumber()
{
	if (ScreenNumberTable.length>0)
	{
		return ScreenNumberTable[ScreenNumberTable.length-1]
	}
}

function AddElmtScreenNumber()
{
	ScreenNumberTable[ScreenNumberTable.length] = 1;
}

function RemoveElmtScreenNumber()
{
	ScreenNumberTable.pop();
}


function SetChapterTitle(chapterTitle)
{
	ChapterTitleTab[ChapterTitleTab.length] = chapterTitle;
}

function GetCurrentChapterTitle()
{
	return (ChapterTitleTab.length > 0) ? ChapterTitleTab[ChapterTitleTab.length-1] : "";
}

function GetChapterTitle()
{
	if (ChapterTitleTab.length>0)
	{//todo: check backTo exists
		var strStepName = ChapterTitleTab[ChapterTitleTab.length-1];
		if (strStepName.length > 0)
			document.write(backTo + strStepName);
		else
			document.write(backToPrev);
	}
	else
	{
		//todo: check endText exists
		document.write(endText);
	}
}

function RemoveElmtChapterTitleTab()
{
	ChapterTitleTab.pop();
}


function AssignStyle(elmt)
{	alert(padding);
	elmt.style="padding-left:" + padding;
}

function GetID()
{
	for(i=0;i<IDTab.length;i++)
	{
		if (IDTab[i] != 0)
		{
			if (i==0)
				result = IDTab[i];
			else
				result = result + "." + IDTab[i];
		}
	}
	//alert(result);
	document.write(result);
}

function SetID()
{   
	IDTab[IDTab.length-1] = IDTab[IDTab.length-1] + 1;
	IDTab[IDTab.length] = 0;
	padding = padding + 10;
	//alert(IDTab.join("."));
}

function SetIDFromAction()
{
	IDTab[IDTab.length-1] = IDTab[IDTab.length-1] + 1;
	//alert(IDTab.join("."));
}

function SetNullIDFromAction()
{
	IDTab.splice(IDTab.length-1, 1);
	padding = padding - 10;
}

function deployer(){
	nodes = document.all;
	for(i=0;i<nodes.length;i++) {
		if(nodes[i].className=="tab") {
			nodes[i].className="tab-expanded";
			
		}
		else if (nodes[i].className=="tab-expanded") {
			nodes[i].className="tab";
			
		}
	}	
}

function getNextSibling(startBrother){
	endBrother=startBrother.nextSibling;
	while(endBrother.nodeType!=1){
		endBrother = endBrother.nextSibling;
	}
	return endBrother;
}

function getChildNodeAt(elmParent, index){
	i=0;
	j=0;
	
	while (j<index)
	{
		node= elmParent.childNodes[i];
		while(node.nodeType!=1){
			i++;
			node = elmParent.childNodes[i];
		}

		j++;
		i++;
	}
	return node;

}

function setObjInnerText(obj, content){
	if (document.all) { // IE;
		obj.innerText = content;
	}
	else{
		if (obj.text)
		{
			obj.textContent = content;
		}
	else
		alert("Error: This application does not support your browser. Try again using IE or Firefox.");
	}
} 

function openAll(){
	//nodes = document.all;
	nodes = document.getElementsByTagName("div");
	for(i=0;i<nodes.length;i++) {
		if(nodes[i].className=="tab") {
			nodes[i].className="tab-expanded";
		}
	}
	document.getElementById("toggle_text").innerText = "收起";
	document.getElementById("toggle_icon").src = "close.gif";
}

function closeAll(){
	//nodes = document.all; not working on firefox
	nodes = document.getElementsByTagName("div");
	for(i=0;i<nodes.length;i++) {
		if (nodes[i].className=="tab-expanded") {
			nodes[i].className="tab";
			
		}
	}
	document.getElementById("toggle_text").innerText = "展开";
	document.getElementById("toggle_icon").src = "open.gif";
}

function toggleAll() {
	if(bOpen) {
		closeAll();
		bOpen = false;
	}
	else {
		openAll();
		bOpen = true;
	}
}

function openOneNode(){
	nodes = document.all;
	for(i=0;i<nodes.length;i++) {
		if(nodes[i].className=="tab") {
			nodes[i].className="tab-expanded";
		}
	}
	document.getElementById("toggle_text").innerText = "收起";
	document.getElementById("toggle_icon").src = "close.gif";
}

function closeOneNode(){
	nodes = document.all;
	for(i=0;i<nodes.length;i++) {
		if (nodes[i].className=="tab-expanded") {
			nodes[i].className="tab";
			
		}
	}
	document.getElementById("toggle_text").innerText = "展开";
	document.getElementById("toggle_icon").src = "open.gif";
}

function toggle(node) {
	//elm = node.nextSibling;
	elm = getNextSibling(node);
	if(elm.className=="tab") {
		elm.className="tab-expanded";
	}
	else
		elm.className="tab";
}

function enlarge(elmParent) {
	
	elmText = getChildNodeAt(elmParent, 1);
	elmText = getChildNodeAt(elmText, 1);
	imgSmall = getChildNodeAt(elmParent, 2);
	imgLarge = getChildNodeAt(elmParent, 3);

	if ((imgSmall) && (imgLarge) && (elmText))
	{
		if (imgSmall.style.display == "none")
		{
			imgSmall.style.display = "block";
			imgLarge.style.display = "none"; 
			setObjInnerText(elmText, "Enlarge");
		}
		else{
			imgSmall.style.display = "none";

			imgLarge2 = getChildNodeAt(imgLarge, 1);
			imgLarge2.style.width = "100%";
			imgLarge.style.display = "block";
			setObjInnerText(elmText, "Reduce");		
		}
	}

}
