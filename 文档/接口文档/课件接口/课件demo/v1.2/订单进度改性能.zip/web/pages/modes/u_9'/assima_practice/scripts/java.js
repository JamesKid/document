﻿var bJavaLoaderReady = false;
var bAutoLaunch = false;
var bLaunched = false;

/**called by the applet when ready*/
function ReadyLink()
{
	/* The javaloader is ready. */
	bJavaLoaderReady = true;
	
	/* Shall we automatically launch the lesson? */
	if ((getValArg(sUrl,"autoLaunch") == "Y") || bAutoLaunch)
	{
		/* Launch the lesson. */
		setTimeout(function() { javascript:runSim('','','',' /tutlang:ENG /simlang:ENG'); }, 2000);
		
		/* Change the message displayed in the button. */
		var _startLink = document.getElementById("LAUNCH_BUTTON");
		if (_startLink != null)
		{
			_startLink.innerHTML = "开始课程……";
		}
	}
}

/**called by the applet when the page has to be refreshed*/
function TriggerRefresh()
{
	/* The javaloader isn't ready. */
	bJavaLoaderReady = false;

	/* Disable launching link. */
	var _startLink = document.getElementById("LAUNCH_BUTTON");
	if (_startLink)
	{
		_startLink.onclick = "";
		_startLink.innerHTML = "正在重载页面……";
	}
	
	/* Timer for the page refresh. */
	setTimeout("NavigateToAutolaunch()", 500);
}


function NavigateToAutolaunch()
{
	var newHref = unescape(location) + "?autoLaunch=Y";
	location.href = newHref;
}


function AutoRun()
{
	/* Start the lesson if  the javaloader is ready. */
	if (bJavaLoaderReady)
	{
		/* Start the lesson after 2 seconds. */
		setTimeout(function() { javascript:runSim('','','',' /tutlang:ENG /simlang:ENG'); }, 2000);
		
		/* Change the message displayed in the button. */
		var _startLink = document.getElementById("LAUNCH_BUTTON");
		if (_startLink != null)
		{
			_startLink.innerHTML = "开始课程……";
		}
	}
	else
	{
		/* Launch the simulation when the javaloader is ready. */
		bAutoLaunch = true;
	}
}


/**Terminate score tracking function*/
function DoTerminateScore(nScore, nTips, nPlayBacks, nErrors, nCorrects, nResumeAction, nTotalStep, strSessionTime)
{
	/*** Allow the user to launch its lesson again */
	bAutoLaunch = false;
	bLaunched = false;
	
	/* Change the message displayed in the button. */
	var _startLink = document.getElementById("LAUNCH_BUTTON");
	if (_startLink != null)
	{
		_startLink.innerHTML = "开始练习";
	}
}


/**called by the java deploy to display the score popup*/
function ShowHTMLScore(nScore, nTips, nPlayBacks, nErrors, nCorrects, nResumeAction, nTotalStep, strSessionTime)
{
	/**set values*/
	objScore.intTipCount		= nTips;
	objScore.intPlaybackCount	= nPlayBacks;
	objScore.intFaultCount		= nErrors;
	objScore.intCorrectCount	= nCorrects;
	objScore.lEndTime			= new Date().getTime();
	objScore.bFinished			= (nResumeAction == -1) ? true : false;
	
	/**we need to calculate the score*/
	switch (0)
	{
		case 0: // Default score mode
		{
			if (nTotalStep != 0)
				objScore.intFinalScore = nScore / nTotalStep;
			else
				objScore.intFinalScore = 0;
			break;
		}
		
		case 1: // Custom score mode
		default:
		{
			objScore.intFinalScore = nScore;
			break;
		}
	}
	
	/**convert the score to a percentage*/
	if (100 != 0)
		objScore.intFinalScore = objScore.intFinalScore * 100 / 100;
	
	/**fire score popup on a "separate thread"*/
	setTimeout("OnScore(objScore);", 0);
}


// Initialize a score structure to receive the results
var objScore = new TScore();
objScore.strTutName = "订单进度改性能";


function runSim(simulation,tutorial,imgdtb,parameters)
{
	/* Make sure we are ready to launch the lesson. */
	if (!bJavaLoaderReady)
	{
		/* Auto-Launch  the lesson later when ready */
		bAutoLaunch = true;
		return false;
	}
	
	/* Make sure that the lesson isnt' already running. */
	if (bLaunched)
		return false;
		
	/* Change the message displayed in the button. */
	var _startLink = document.getElementById("LAUNCH_BUTTON");
	if (_startLink != null)
	{
		_startLink.innerHTML = "正在运行课程……";
	}
	
	/* Remember when we began this lesson*/
	objScore.lBeginTime = new Date().getTime();
	
	/**Launch Sim*/
	bLaunched = true;
	setTimeout("JavaLoader.Main('tut_desc.xml','');", 0);
}
