﻿function popUpDownload(URL)
{
	day = new Date();
	id = day.getTime();
	eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=730,height=630,left=120,top=80');");
}

function PopUpFullScreen(sUrl)
{
	var y=window.screen.height;
	var x=window.screen.width;

	var winFullScreen=window.open(sUrl, 'FullScreen', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,fullscreen');
}

window.frameFullScreen = null;
function FrameFullScreen(sUrl)
{
	// Get or create a full screen frame
	if (window.frameFullScreen == null)
		window.frameFullScreen = CreateFrameFullScreen();
	
	// Set its url
	window.frameFullScreen.src = sUrl;
	
	// Display the frame
	window.frameFullScreen.style.display = "";
}

function CloseFrameFullScreen()
{
	// Destroy the frame
	if (window.frameFullScreen != null)
	{
		// Clear the resize timeout
		if (window.frameFullScreenTimer != null)
		{
			clearTimeout(window.frameFullScreenTimer);
			window.frameFullScreenTimer = null;
		}
		
		// Remove the the iframe from the DOM
		window.frameFullScreen.src = "about:blank";
		document.body.removeChild(window.frameFullScreen);
		window.frameFullScreen = null;
	}
}

function CreateFrameFullScreen()
{
	// Create a new frame that will cover the whole window
	var frameFullScreen = document.createElement("iframe");
	frameFullScreen.border = 0;
	frameFullScreen.style.border = "none";
	frameFullScreen.style.margin = "0";
	frameFullScreen.style.position = "absolute";
	frameFullScreen.style.top = "0";
	frameFullScreen.style.left = "0";
	frameFullScreen.style.bottom = "0";
	frameFullScreen.style.right = "0";
	frameFullScreen.style.zIndex = 100000000;
	
	// Add the frame to the body
	document.body.appendChild(frameFullScreen);
	
	// IE ?
	if (navigator.userAgent.indexOf(' MSIE ') > -1)
	{
		// Get document mode
		var version = parseFloat(navigator.userAgent.match(/MSIE (\d+\.\d+)/)[1]);
		var documentMode = (version >= 8) ? document.documentMode : 0;
		
		// If running on IE < 8 or IE 8 compat mode, we have to explicitly set the dimensions of the frame
		if (documentMode < 8)
		{
			// Set a timer that will update it automatically every now and then
			ResizeFrameFullScreenTimer(frameFullScreen);
		}
	}
	
	return frameFullScreen;
}

function ResizeFrameFullScreenTimer(frame)
{
	// Make sure the frame is valid
	if (frame == null || frame.parentNode == null)
		return;
	
	try
	{
		ResizeFrameFullScreen(frame);
		setTimeout(function() { ResizeFrameFullScreenTimer(frame); }, 500);
	}
	catch (e) {}
}

function ResizeFrameFullScreen(frame)
{
	// Get the inner dimensions of the the window
	var dimensions = GetWindowInnerDimensions();
	
	// Need to adjust the size of the frame?
	if (dimensions.width != frame.offsetWidth || dimensions.height != frame.offsetHeight)
	{
		frame.style.width = dimensions.width + "px";
		frame.style.height = dimensions.height + "px";
	}
}

function GetWindowInnerDimensions()
{
	var dim = { width: 0, height: 0 };
	
	if (typeof(window.innerWidth) == 'number') //Non-IE
	{
		dim.width = window.innerWidth;
		dim.height = window.innerHeight;
	} 
	else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) //IE 6+ in 'standards compliant mode'
	{
		dim.width = document.documentElement.clientWidth;
		dim.height = document.documentElement.clientHeight;
	}
	else if (document.body && (document.body.clientWidth || document.body.clientHeight)) //IE 4 compatible
	{
		dim.width = document.body.clientWidth;
		dim.height = document.body.clientHeight;
	}
	
	return dim;
}