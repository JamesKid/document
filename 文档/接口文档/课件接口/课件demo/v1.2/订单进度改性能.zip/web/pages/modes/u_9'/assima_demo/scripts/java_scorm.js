﻿var bJavaLoaderReady = false;
var bAutoLaunch = false;
var bLaunched = false;
var bInitialized = false;

/**called by an applet when ready*/
function ReadyLink()
{
	/* The javaloader is ready. */
	bJavaLoaderReady = true;
		
	/* Shall we start the lesson automatically ? */
	if (getValArg(sUrl,"autoLaunch") == "Y" || bAutoLaunch)
	{
		/* Start the lesson after 2 seconds. */
		bInitialized = true;
		setTimeout("Initialize()", 2000);
	}
}


function TriggerRefresh()
{
	/* The javaloader isn't ready! */
	bJavaLoaderReady = false;
	
	/* Disable launching link. */
	var _startLink = document.getElementById("LAUNCH_BUTTON");
	if (_startLink)
	{
		_startLink.innerHTML = "请稍后，您的页面正在重新装载中……";
	}
	
	/* Timer for the page refresh. */
	setTimeout("NavigateToAutolaunch()", 500);
}


function NavigateToAutolaunch()
{
	var newHref = unescape(location) + "?autoLaunch=Y";
	location.href = newHref;
}


function AutoRun()
{
	/* Start the lesson if  the javaloader is ready and we've not yet initialized. */
	if (bJavaLoaderReady && !bInitialized)
	{
		/* Start the lesson after 2 seconds. */
		bInitialized = true;
		setTimeout("Initialize()", 2000);
	}
	else
	{
		/* Launch the simulation when the javaloader is ready. */
		bAutoLaunch = true;
	}
}


/**called by the java deploy to display the score popup*/
function ShowHTMLScore(nScore, nTips, nPlayBacks, nErrors, nCorrects, nResumeAction, nTotalStep, strSessionTime)
{
	/* Nothing to do. */
}


function Initialize()
{
	/**Tell the user the simulation is now loading*/
	var _startLink = document.getElementById("LAUNCH_BUTTON");
	if (_startLink)
	{
		_startLink.innerHTML = "你的课程正在装载，请稍后……";
		_startLink.style.display = "inline";
	}
	
	/**Initialize SCORM */
	DoInitializeSCORM();
}

/**Terminate score tracking function*/
function DoTerminateScore(nScore, nTips, nPlayBacks, nErrors, nCorrects, nResumeAction, nTotalStep, strSessionTime)
{
	/* Compute the number of steps that have just been completed. */
	//var nCompletedSteps = nTotalStep; // [#17717] Correct value is returned in nTotalStep
	
	/* Overwrite the returned score so that we always score 100 in demo mode. */
	var nCompletedSteps = 1;
	nScore = 100;
	
	/* Terminate the scorm session (in a "separate thread", not to block the javaloader). */ 
	setTimeout("DoTerminateSCORM(" + nScore + ", " + nCompletedSteps + ", " + nTotalStep + ", \"" + strSessionTime + "\", " + nResumeAction + ");", 250);
	
	/**Tell the user that the simulation is finished.*/
	var _startLink = document.getElementById("LAUNCH_BUTTON");
	if (_startLink)
	{
		_startLink.onclick = "";
		_startLink.innerHTML = "窗口正在关闭，请稍后...";
	}
}

/**Resume a lesson. */
function Resume()
{
	Launch(g_nResumeAction);
}

/**Restart a lesson. */
function Restart()
{
	g_nPreviousSteps = null;
	g_nPreviousScore = null;
	g_nResumeAction = _NO_RESUME;
	Launch(_NO_RESUME);
}

/**Launch function in Java Mode*/
function Launch(nResumeAction)
{
	/** Check if we are ready to launch the simulation and if it's not already launched. */
	if (!bJavaLoaderReady || bLaunched)
		return false;
	
	/**the extra params*/
	var strExtraParam = "";
	
	/**Do we have to resume the lesson?*/
	if (nResumeAction != _NO_RESUME)
		strExtraParam += " /tutaction:" + nResumeAction;
	
	/**Tell the user the simulation has been launched*/
	var _startLink = document.getElementById("LAUNCH_BUTTON");
	if (_startLink)
	{
		_startLink.onclick = "";
		_startLink.innerHTML = "您的课程已经开始运行……";
	}
	
	/**Launch Sim*/
	bLaunched = true;
	setTimeout("JavaLoader.Main('tut_desc.xml', '" + strExtraParam + "');", 0);
}
