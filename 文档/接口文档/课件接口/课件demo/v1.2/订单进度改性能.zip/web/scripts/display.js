﻿/**Constants*/
var MIN_SCORE = 50;

//displays a box with a header and a content.
function displaybox(boxclass,contentclass,header,boxcontent,boxid) {
	document.write("<div class='" + boxclass + "'>");
	document.write("<table class='box-header'><tr><td class='leftcorner'></td><td class='middlepart'>");
	document.write(header);
	document.write("</td><td class='rightcorner'></td></tr></table>");
	document.write("<div class='" + contentclass + "' id='" + boxid + "'>" + boxcontent + "</div>");
	document.write("</div>");
}

//displays a banner						
function displaybanner(bannerclass,bannercontent) {
	document.write("<div class='" + bannerclass + "'>");
	document.write("<table class='banner-content'><tr><td class='leftbound'></td><td class='middlepart'>");
	document.write(bannercontent);
	document.write("</td><td class='rightbound'></td></tr></table>");
}

//displays a box with a header, and which content is a flash animation
function displayflash(boxclass,header,filename,boxid) {
	document.write("<div class='" + boxclass + "'>");
	document.write("<table class='box-header'><tr><td class='leftcorner'></td><td class='middlepart'>");
	document.write(header);
	document.write("</td><td class='rightcorner'></td></tr></table>");
	document.write("<div class='content-flash'id='" + boxid + "'>");
	document.write("<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0' width='241' height='160'>");
	document.write("<param name='movie' value='" + filename + "'/>");
	document.write("<param name='quality' value='high'/>");
	document.write("<param name='bgcolor' value='#FFFFFF'/>");
	document.write("<embed quality='high' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' src='" + filename + "' width='241' height='160'/>");
	document.write("</object>");
	document.write("</div>");
	document.write("</div>");
}

//modify the smaller box b/w box1 and box2, so that the two boxes have the same height
function equalizeboxes (box1,box2) {
	leftbox=document.getElementById(box1);
	rightbox=document.getElementById(box2);
	if(leftbox.offsetHeight > rightbox.offsetHeight)
		rightbox.style.height = leftbox.offsetHeight;
	else
		leftbox.style.height = rightbox.offsetHeight;
	
	if(leftbox.offsetHeight + leftbox.offsetTop + leftbox.offsetParent.offsetTop > document.body.offsetHeight*4/5) {
		rightbox.style.height = document.body.offsetHeight*4/5 - leftbox.offsetTop - leftbox.offsetParent.offsetTop;
		leftbox.style.height = rightbox.offsetHeight;
	}
}

/**********************************************************************
*
*					Functions used to display a score 
*
**********************************************************************/

//Create the score rows table
function CreateScoreTable()
	{
	/**Create the score table*/
	var ScoreTable = document.createElement("TABLE");
	ScoreTable.setAttribute("id", "ScoreRowsTable");
	ScoreTable.setAttribute("width", "100%");
	//border for debug*/
	//ScoreTable.setAttribute("border", "1");
	document.getElementById("ScoreRows").appendChild(ScoreTable);
	var TableBody = document.createElement("TBODY");
	ScoreTable.appendChild(TableBody);			
	/**return the body of the score table*/
	return TableBody;
	}
//Create the tutorial cell
function CreateTutCell(objScore, ScoreType, nTry, TutName)
	{
	var TutCell = document.createElement("TD");
	TutCell.setAttribute("className", "ScoreRow");
	TutCell.setAttribute("width", "30%");
	/**Create the table inside this cell*/
	var theTable = document.createElement("TABLE");
	var theTableBody = document.createElement("TBODY");
	theTable.appendChild(theTableBody);
	TutCell.appendChild(theTable);
	/**Create the row inside this table*/
	var theRow = document.createElement("TR");
	theTableBody.appendChild(theRow);
	/**Create the icon cell*/
	var theIconCell = document.createElement("TD");
	theIconCell.setAttribute("width","6");
	theIconCell.setAttribute("className", "ScoreImage" + ScoreType);
	/**Create the tutname cell*/
	var TutNameCell = document.createElement("TD");
	TutNameCell.setAttribute("className", "ScoreRow");
	TutNameCell.innerHTML = "<a href=\"#\" onclick=\"javascript:PopupScore('" + escape(objScore.toJSONString()) + "');\">"+unescape(TutName)+"</a>";
	/**Append the cells to the row*/
	theRow.appendChild(theIconCell);
	theRow.appendChild(TutNameCell);
	/**return the tutorial cell*/
	return TutCell;
	}
//Create the beg time cell
function CreateBegCell(BegTime)
	{
	/**create the beg time cell*/
	var BegCell = document.createElement("TD");
	BegCell.setAttribute("className", "ScoreRow");
	BegCell.setAttribute("width", "15%");
	/**Add the beg time*/
	BegCell.innerHTML = new Date(BegTime).toLocaleString();
	/**return the beg time cell*/
	return(BegCell);
	}
//Create the score bar cell
function CreateScoreBarCell(FinalScore, MinScore, bFinished)
	{
	/**Create the table inside the cell*/
	var ScoreBarCell = document.createElement("TD");
	var ScoreBarTable = document.createElement("TABLE");
	var ScoreBarTBody = document.createElement("TBODY");
	ScoreBarCell.appendChild(ScoreBarTable);
	ScoreBarTable.appendChild(ScoreBarTBody);
	/**Create the only row of this table*/
	var theRow = document.createElement("TR");
	ScoreBarTBody.appendChild(theRow);
	/**Create the colored cell*/
	var theColoredCell = document.createElement("TD");
	theRow.appendChild(theColoredCell);
	/**Create the gray cell*/
	var theGrayCell = document.createElement("TD");
	theRow.appendChild(theGrayCell);

	/**Set TheScoreTable attributes*/
	ScoreBarTable.setAttribute("valign", "middle");
	ScoreBarTable.setAttribute("cellspacing", "0");
	ScoreBarTable.setAttribute("cellspadding", "0");
	ScoreBarTable.setAttribute("width", "100%");
	ScoreBarTable.setAttribute("border", "1");
	
	/**Set the row attributes*/
	theRow.setAttribute("width", "100%");
	theRow.setAttribute("height", "20");
	
	/**Set the colored cell attribute*/
	theColoredCell.setAttribute("width", FinalScore+"%");
	/**Sets the good Score bar color*/
	if (!bFinished)
		{
		theColoredCell.setAttribute("className", "imageScoreBarNOT");
		}
	else
		{
		if (FinalScore >= MinScore)
			theColoredCell.setAttribute("className", "imageScoreBarOK");
		else
			theColoredCell.setAttribute("className", "imageScoreBarKO");
		}
	/**Set the attributes of the gray cell*/
	theGrayCell.setAttribute("bgColor", "gray");
	theGrayCell.setAttribute("width", (100-FinalScore)+"%");
	/**Don't display any gray cell if score=100*/
	if (FinalScore == 100)
		theGrayCell.style.display = "none";
	/**The same if score==0*/
	if (FinalScore == 0)
		theColoredCell.style.display = "none";
	/**return the cell created*/
	return (ScoreBarCell);
	}
//Create the minimum score required cell
function CreateMinScoreCell(MinScore)
	{
	/**Create the table inside the cell*/
	var MinScoreCell = document.createElement("TD");
	var MinScoreTable = document.createElement("TABLE");
	var MinScoreTBody = document.createElement("TBODY");
	MinScoreCell.appendChild(MinScoreTable);
	MinScoreTable.appendChild(MinScoreTBody);
	/**Create the only row of this table*/
	var theRow = document.createElement("TR");
	MinScoreTBody.appendChild(theRow);
	/**Create the colored cell*/
	var theLeftCell = document.createElement("TD");
	theRow.appendChild(theLeftCell);
	/**Create the gray cell*/
	var theRightCell = document.createElement("TD");
	theRow.appendChild(theRightCell);

	/**Set TheScoreTable attributes*/
	MinScoreTable.setAttribute("valign", "middle");
	MinScoreTable.setAttribute("cellspacing", "0");
	MinScoreTable.setAttribute("cellspadding", "0");
	MinScoreTable.setAttribute("width", "100%");
	
	/**Set the attributes of the minimum score row*/
	theRow.setAttribute("width", "100%");
	theRow.setAttribute("height", "8");
	
	/**Set the attributes of the left triangle cell*/
	theLeftCell.setAttribute("width", MinScore+"%");
	theLeftCell.setAttribute("className", "imageScoreLeftTriangle");
	
	/**Set the attributes of the right triangle cell*/
	theRightCell.setAttribute("width", (100-MinScore)+"%");
	theRightCell.setAttribute("className", "imageScoreRightTriangle");
	
	/**if the minimum score is 100% we don't display the right triangle*/
	if (MinScore == 100)
		theRightCell.style.display = "none";
	if (MinScore == 0)
		theLeftCell.style.display = "none";
	/**return the cell created*/
	return (MinScoreCell);
	}
//Create the score bar and mini score cell
function CreateScoreRowCell(ScoreType, FinalScore, MinScore, bFinished)
	{
	/**Create the score cell*/
	var ScoreRowCell = document.createElement("TD");
	ScoreRowCell.setAttribute("className", "ScoreRow");
	ScoreRowCell.setAttribute("width", "30%");
	ScoreRowCell.setAttribute("align", "center");
	
	/**Create the table*/
	var theTable = document.createElement("TABLE");
	var theTableBody = document.createElement("TBODY");
	theTable.appendChild(theTableBody);
	ScoreRowCell.appendChild(theTable);
	
	/**Create the score bar row*/
	var theScoreRow = document.createElement("TR");
	theTableBody.appendChild(theScoreRow);
	
	/**Create and append the score bar cell*/
	var ScoreBarCell = CreateScoreBarCell(FinalScore, MinScore, bFinished);
	theScoreRow.appendChild(ScoreBarCell);
	
	/**Set the attributes of the score row*/
	theScoreRow.setAttribute("width", "100%");
	
	if ((ScoreType != "Demo")&&(ScoreType != "Document"))
		{
		/**Create the min score row*/
		var theMinRow = document.createElement("TR");
		theTableBody.appendChild(theMinRow);

		/**Create and append the min score cell*/
		var MinScoreCell = CreateMinScoreCell(MinScore);
		theMinRow.appendChild(MinScoreCell);
		
		/**Set the attributes of the min score row*/
		theMinRow.setAttribute("width", "100%");
		}
	
	/**Set the attributes of the table*/
	theTable.setAttribute("valign", "middle");
	theTable.setAttribute("cellspacing", "0");
	theTable.setAttribute("cellspadding", "0");
	theTable.setAttribute("width", "100%");

	/**Return the cell created*/
	return(ScoreRowCell);
	}
//Create the score only cell
function CreateScoreCell(ScoreType, FinalScore)
	{
	/**create the score cell*/
	var ScoreCell = document.createElement("TD");
	ScoreCell.setAttribute("className", "ScoreRow");
	ScoreCell.setAttribute("width", "10%");
	if ((ScoreType != "Demo")&&(ScoreType != "Document"))
		{
		/**Add the final score*/
		var nRoundScore = new Number(FinalScore);
		if (nRoundScore != nRoundScore.toFixed(2)) // [#17375] If the score has more than 2 decimals, only keep the first 2 of them
			nRoundScore = (nRoundScore.toFixed(2) == 0) ? 0 : nRoundScore.toFixed(2);
		ScoreCell.innerHTML = nRoundScore+"%";
		}
	/**return the beg time cell*/
	return(ScoreCell);
	}
//Create the duration cell
function CreateDurationCell(BegTime, EndTime)
	{
	/**first build the duration string*/
	var date1 = new Date(BegTime);
	var date2 = new Date(EndTime);
	
	var secs = (date2-date1) / 1000;
	var mins = secs / 60;
	mins = Math.floor(mins); // floor the minutes
	secs = secs - mins*60;
	
	var Duration="";
	if(Math.max(mins,1) == mins)
		Duration = mins+" 分 ";
	else if(Math.max(mins,0) == mins)
		Duration = mins+" 分 ";
	Duration = Duration+secs+" 秒";
	
	/**Create the duration cell*/
	var DurationCell = document.createElement("TD");
	DurationCell.setAttribute("className", "ScoreRow");
	DurationCell.setAttribute("width", "15%");
	/**Add the beg time*/
	DurationCell.innerHTML = Duration;
	/**return the beg time cell*/
	return(DurationCell);
	}
//Add the score to the page
function AddScore(objScore)
	{
	/**Check if the score table doesn't exist already*/
	var ScoreTable = document.getElementById("ScoreRowsTable");
	if (ScoreTable == null)
		{
		/**Create the score table*/
		ScoreTable = CreateScoreTable();
		}
	/**Get the number of rows to append the scores*/	
	var lastRow = ScoreTable.rows.length;
	/**Create the score row*/
	var ScoreRow = ScoreTable.insertRow(lastRow);
	/**Create the tutorial cell and append it to the row*/
	var TutCell = CreateTutCell(objScore, objScore.strResultText, objScore.intTryCount, objScore.strTutName);
	ScoreRow.appendChild(TutCell);
	/**Create the beg time cell and append it to the row*/
	var BegCell = CreateBegCell(objScore.lBeginTime);
	ScoreRow.appendChild(BegCell);
	/**Create the graphic score cell and append it to the row*/
	var ScoreRowCell = CreateScoreRowCell(objScore.strResultText, objScore.intFinalScore, MIN_SCORE, objScore.bFinished);
	ScoreRow.appendChild(ScoreRowCell);
	/**Create the score cell and append it to the row*/
	var ScoreCell = CreateScoreCell(objScore.strResultText, objScore.intFinalScore);
	ScoreRow.appendChild(ScoreCell);
	/**Create the duration cell and append it to the row*/
	var DurationCell = CreateDurationCell(objScore.lBeginTime, objScore.lEndTime)
	ScoreRow.appendChild(DurationCell);
	}

/*** Function called by the main frame when a score is ready to be displayed. ***/
function PopupScore(strScore)
	{
		/* Setup the how the popup will be displayed. */
		var strOptions = 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=1,width=410,height=400,left=50,top=50';
		
		/* Show the results in a popup. */
		window.open("resultsimul.htm?" + unescape(strScore), '_blank', strOptions);
	}
/**********************************************************************
*
*			Functions used to display an EPSS query result
*
**********************************************************************/
function CreateInfoCell(Mode, Lang, Match)
	{
	var InfoCell = document.createElement("TD");
	var theClass = "";
	/**Set the attributes for the Info cell*/
	InfoCell.setAttribute("valign", "top");
	InfoCell.setAttribute("width", "5%");
	/**Create the table inside this cell*/
	var theTable = document.createElement("TABLE");
	var theTableBody = document.createElement("TBODY");
	theTable.appendChild(theTableBody);
	InfoCell.appendChild(theTable);
	var theRow = document.createElement("TR");
	theTableBody.appendChild(theRow);
	/**Set attribute for the table and the row*/
	theTable.setAttribute("width", "100%");
	theRow.setAttribute("width", "100%");
	
	
	/**Create the icon cell*/
	var theIconCell = document.createElement("TD");
	theRow.appendChild(theIconCell);
	/**Set the attributes for this cell*/
	theIconCell.innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;";
	switch(Mode)
		{
		case "0":
		theClass = "ScoreImagePracticeMode";
		break;
		
		case "1":
		theClass = "ScoreImageMovieMode";
		break;
		
		case "2":
		theClass = "ScoreImageTestMode";
		break;
	}
	theIconCell.setAttribute("className", theClass);
	theIconCell.setAttribute("width", "34%");
	
	/**Create the flag cell*/
	var theFlagCell = document.createElement("TD");
	theFlagCell.innerHTML = "<img alt=\""+Lang+"\" src=\"images/"+Lang+".ico\" height=\"24\" width=\"24\">";
	theRow.appendChild(theFlagCell);
	/**Set the attribute for this cell*/
	theFlagCell.setAttribute("width", "33%");	
	
	/**Create the matching cell*/
	var theMatchCell = document.createElement("TD");
	var MatchVal = Math.round(Match);
	if (MatchVal < 100)
		MatchVal = 100;
	theMatchCell.innerText = MatchVal + "%";
	theRow.appendChild(theMatchCell);
	theMatchCell.setAttribute("className", "IDBText");
	/**Set the attribute for this cell*/
	theMatchCell.setAttribute("width", "33%");
		
	/**Return the cell*/
	return InfoCell;
	}
// TODO: update the following function
function CreateTutNameCell(Step, TotalStep, TutName, Lang, File)
	{
	//alert(File);
	Pos = File.indexOf(".");
	Name = File.substring(0, Pos-4);
	ResumFile = "../../simul/"+Lang+"/"+Name+"_htm/"+Name+"_desc_idb.htm";
	//alert(ResumFile);
	Param = "javascript:window.open('"+ResumFile+"', '_self');";
	//alert(Param);

	/**Create the tutname cell*/
	var TutNameCell = document.createElement("TD");
	TutNameCell.setAttribute("className", "ScoreRow");
	TutNameCell.setAttribute("width", "45%");
	TutNameCell.innerHTML = "<a href=# onclick=\""+Param+"\">"+TutName+"</a>";
	//TutNameCell.innerHTML = "<a href=# onclick=\"JavaScript:runSim('"+Sim+"','"+Tut+"','"+ImgDB+"','"+Param+"/tutaction:"+Step+"');\">"+TutName+"</a>";
	/**To display the number of step use a function in the html page for the translation*/
	Step = Step.slice(1);
	TutNameCell = AddStepNumber(TutNameCell, Step, TotalStep);
	
	/**return the tutorial cell*/
	return TutNameCell;	
	}
function CreateDescCell(Description)
	{
	var theDescription;
	/**manipulate the description to only have about 150 characters*/
	if (Description.length > 150)
		{
		var i = 150;
		while (Description.substr(i,1) != ' ')
			{
			i--;
			}
		theDescription = Description.substring(0, i) + "...";
		}
	else theDescription = Description;
	
	var DescCell = document.createElement("TD");
	DescCell.setAttribute("width", "50%")
	/**Create the table inside this cell*/
	var theTable = document.createElement("TABLE");
	var theTableBody = document.createElement("TBODY");
	theTable.appendChild(theTableBody);
	DescCell.appendChild(theTable);
	theTable.setAttribute("border", "1");
	theTable.setAttribute("width", "90%");
	theTable.setAttribute("height", "75%");
	/**Create the row inside this table*/
	var theRow = document.createElement("TR");
	theTableBody.appendChild(theRow);
	/**Create the icon cell*/
	var theIconCell = document.createElement("TD");
	theIconCell.setAttribute("width","100%");
	theIconCell.setAttribute("className", "information");
	theIconCell.innerHTML = theDescription;
	/**Append the cells to the row*/
	theRow.appendChild(theIconCell);
	/**return the tutorial cell*/
	return DescCell;	
	}
function AddQueryResult(QueryResult)
	{
	//For debug display the query result received
	//alert(unescape(QueryResult));
	
	/**Extract from the Query result the name of the tut*/
	var theResult = unescape(QueryResult);
	/**format it as an xml string*/
	var XMLString = "<xml>"+theResult+"</xml>";
	
	/**Put the result string in an XML document*/
	var xmlDoc=new ActiveXObject("Microsoft.XMLDOM")
	xmlDoc.async="false"
	xmlDoc.loadXML(XMLString)
	
	document.getElementById("ResultsFieldSet").style.display = "block"
	
	/**Retrieve the results table element*/
	var theTable = document.getElementById("ResultsTable");

	/**Check we have retrieved a valid XML document and a valid table*/
	if ((xmlDoc != null)&&(theTable != null))
		{
		/**Retrieve the number of results*/
		var TutNum = xmlDoc.getElementsByTagName("RESOURCE").length;
		/**if we have no result use the function in the HTML page to display the error message in the good language*/
		if (TutNum == 0)
			noResult();
		/**if we have some results we display the table*/
		else
			{
			theFieldSet = document.getElementById("ResultsTable");
			if (theFieldSet)
				theFieldSet.style.display = "block";
			}
			
		/**Loop on all the results*/
		for (var iCount=0; iCount<TutNum; iCount++)
			{
			/**Retrieve the informations contained in the xml document*/
			var LessonMode = -1;
			/*if (xmlDoc.getElementsByTagName("MODE")[iCount].firstChild != null)
				LessonMode = xmlDoc.getElementsByTagName("MODE")[iCount].firstChild.nodeValue;*/
				
			/*
			var Sim = "";
			if (xmlDoc.getElementsByTagName("SIMNAME")[iCount].firstChild != null)
				Sim = xmlDoc.getElementsByTagName("SIMNAME")[iCount].firstChild.nodeValue;*/
			
			var File ="";
			if (xmlDoc.getElementsByTagName("SYNOPSIS")[iCount].firstChild != null)
				File = xmlDoc.getElementsByTagName("SYNOPSIS")[iCount].firstChild.nodeValue;
				
			/*var Tut = "";
			if (xmlDoc.getElementsByTagName("TUTNAME")[iCount].firstChild != null)
				Tut = xmlDoc.getElementsByTagName("TUTNAME")[iCount].firstChild.nodeValue;
			
			var ImgDB= "";
			if (xmlDoc.getElementsByTagName("IMGDB")[iCount].firstChild != null)
				ImgDB = xmlDoc.getElementsByTagName("IMGDB")[iCount].firstChild.nodeValue;
				
			var Param = "";
			if (xmlDoc.getElementsByTagName("PARAM")[iCount].firstChild)
				Param = xmlDoc.getElementsByTagName("PARAM")[iCount].firstChild.nodeValue;*/
				
			var Step = "";
			/*if (xmlDoc.getElementsByTagName("ACTION")[iCount].firstChild != null)
				Step = xmlDoc.getElementsByTagName("ACTION")[iCount].firstChild.nodeValue;*/
				
			var TotalStep = 0;
			/*if (xmlDoc.getElementsByTagName("TOTALACTION")[iCount].firstChild != null)
				TotalStep = xmlDoc.getElementsByTagName("TOTALACTION")[iCount].firstChild.nodeValue;*/
			
			var TutName = "";
			if (xmlDoc.getElementsByTagName("NAME")[iCount].firstChild != null)
				TutName = xmlDoc.getElementsByTagName("NAME")[iCount].firstChild.nodeValue;
			
			var Match = "";
			if (xmlDoc.getElementsByTagName("SCORE")[iCount].firstChild != null)
				Match = xmlDoc.getElementsByTagName("SCORE")[iCount].firstChild.nodeValue;
			
			var Desc = "";
			if (xmlDoc.getElementsByTagName("STATEMENT")[iCount].firstChild != null)
				Desc = xmlDoc.getElementsByTagName("STATEMENT")[iCount].firstChild.nodeValue;
			
			var Lang = "";
			if (xmlDoc.getElementsByTagName("LANG")[iCount].firstChild != null)
				Lang = xmlDoc.getElementsByTagName("LANG")[iCount].firstChild.nodeValue;
			
			/**Get the number of rows of this table*/
			var lastRow = theTable.rows.length;
			/**Add a new row to the table*/
			var theResultRow = theTable.insertRow(lastRow);
			theResultRow.setAttribute("width", "100%");
			
			/**Add the tutorial information cell*/
			var InfoCell = CreateInfoCell(LessonMode, Lang, Match);
			theResultRow.appendChild(InfoCell);
			
			/**Add the tutorial name cell*/
			var TutNameCell = CreateTutNameCell(Step, TotalStep, TutName, Lang, File);
			theResultRow.appendChild(TutNameCell);
			
			/**Add the description cell*/
			var DescCell = CreateDescCell(Desc);
			theResultRow.appendChild(DescCell);
			}
		}
	}
/**********************************************************************
*
*			Functions used to display the EPSS processes
*
**********************************************************************/
/**Add a query button inside a cell*/
function AddQueryButton(theCell, pid, theProcessName)
	{
	theParameters = "?process="+pid+"&processName="+theProcessName+"&status=true";
	theOnClick = "onclick='javascript:window.open(\"idb_querypage.htm"+theParameters+"\", \"_self\");'";
	theHTML = "<a href='#'><input class='scoreEdit' type='button' value='"+HelpMeValue+"' "+theOnClick+"/></a>";
	theCell.innerHTML = theHTML;
	}

/**Add a process*/
function AddProcess(ProcessName, pid, TempFolder, ProcessRunning)
	{
	var j = 0;
	var theTempFolder = unescape(TempFolder);
	var theIcon = "\""+theTempFolder+"PID_"+pid+".ico\"";
	
	var theProcessRowName = ProcessName+"ROW"
	/**Check if the element doesn't already exists and if the process is running*/
	if (!document.getElementById(theProcessRowName) && ProcessRunning)
		{
		/**Get the table*/
		var theTable = document.getElementById("ProcessTable");
		/**Check if the table exists*/
		if (theTable != null)
			{
			/**Get the number of rows of this table*/
			var lastRow = theTable.rows.length;
			/**Add a new row to the table*/
			var theProcessRow = theTable.insertRow(lastRow);
			
			/**Add the process icon cell*/
			var ProcessIconCell = document.createElement("TD");
			ProcessIconCell.innerHTML = "<img src="+theIcon+"/>";			
			theProcessRow.appendChild(ProcessIconCell);
			
			/**Add the process name cell*/
			var ProcessNameCell = document.createElement("TD");
			if (ProcessName.indexOf("iexplore.exe")!=-1)
				{
				/**It's an iexplore process just display the title*/
				theProcessName = ProcessName.slice(0,-13);
				}
			else
				{
				/**It's not an Iexplore process just display the name of it without the .exe extension*/
				theProcessName = ProcessName.slice(0,-4);
				/**Upcase the first letter*/
				
				}
			ProcessNameCell.innerHTML = theProcessName;
			theProcessRow.appendChild(ProcessNameCell);
			
			/**Add the query button cell*/
			var QueryCell = document.createElement("TD");
			theProcessRow.appendChild(QueryCell);
			/**In this cell add a query bouton*/
			AddQueryButton(QueryCell, pid, theProcessName)				
			
			/**Set the process row attribute*/
			theProcessRow.setAttribute("id", theProcessRowName);
			/**Set the process name cell attribute*/
			ProcessNameCell.setAttribute("className", "scoreRow");
			}
		}
	//alert(document.body.innerHTML);
	}