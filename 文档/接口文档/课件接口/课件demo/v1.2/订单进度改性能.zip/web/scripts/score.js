﻿/***************************************************************************
*  ASSIMA 2007
****************************************************************************/

/****************************************************************************
* NAME: TScore
* DSC.: Initialize a score structure
****************************************************************************/
function TScore()
{
	this.strTutName = "";
	this.strGroupName = "";
	this.strUserId = "";
	this.intTipCount = 0;
	this.intPlaybackCount = 0;
	this.intFaultCount = 0;
	this.intCorrectCount = 0;
	this.intFinalScore = 0;
	this.lBeginTime = "";
	this.lEndTime = "";
	this.bFinished = false;
}


/****************************************************************************
* NAME: HasScore
* DSC.: Tell if the current user has a score in the database.
* RET.: True/False
****************************************************************************/

function HasScore()
{
	/* Ask ATS Portal window. */
	try
	{
		var strBool = window.external.HasScore();
		return eval(strBool);
	}
	catch (e)
	{
		/* Default. */
		return false;
	}
}


/****************************************************************************
* NAME: GetLatestScores
* DSC.: Get the latest scores for the current user.
* RET.: An array of score objects.
****************************************************************************/

function GetLatestScores()
{
	/* Ask ATS Portal window. */
	try
	{
		/* ATS will return the array has a string, so we have to evaluate it before being able to	use it. */
		var strArray = window.external.GetLatestScores();
		return eval(strArray);
	}
	catch (e)
	{
		/* Default. */
		return new Array();
	}
}


/****************************************************************************
* NAME: GetWeekScores
* DSC.: Get the scores from the latest week for the current user.
* RET.: An array of score objects.
****************************************************************************/

function GetWeekScores()
{
	/* Ask ATS Portal window. */
	try
	{
		/* ATS will return the array has a string, so we have to evaluate it before being able to	use it. */
		var strArray = window.external.GetWeekScores();
		return eval(strArray);
	}
	catch (e)
	{
		/* Default. */
		return new Array();
	}
}


/****************************************************************************
* NAME: GetAllScores
* DSC.: Get all the scores for the current user.
* RET.: An array of score objects.
****************************************************************************/

function GetAllScores()
{
	/* Ask ATS Portal window. */
	try
	{
		/* ATS will return the array has a string, so we have to evaluate it before being able to	use it. */
		var strArray = window.external.GetAllScores();
		return eval(strArray);
	}
	catch (e)
	{
		/* Default. */
		return new Array();
	}
}


/****************************************************************************
* NAME: GetScoresByDates
* DSC.: Get all the scores that were carried out between two dates by the current user.
* ARG.: lBeginTime: the beginning date (in milliseconds since midnight Jan 1, 1970)
*	 lEndTime: the end date (in milliseconds since midnight Jan 1, 1970)
* RET.: An array of score objects.
****************************************************************************/

function GetScoresByDates(lBeginTime, lEndTime)
{
	/* Ask ATS Portal window. */
	try
	{
		/* ATS will return the array has a string, so we have to evaluate it before being able to	use it. */
		var strArray = window.external.GetScoresByDates(lBeginTime, lEndTime);
		return eval(strArray);
	}
	catch (e)
	{
		/* Default. */
		return new Array();
	}
}


/****************************************************************************
* NAME: GetScoresByMinimum
* DSC.: Get all the scores for which the result is greater than the minimu given.
* ARG.: intMinScore: the minimum score (integer value between [0-100])
* RET.: An array of score objects.
****************************************************************************/

function GetScoresByMinimum(intMinScore)
{
	/* Ask ATS Portal window. */
	try
	{
		/* ATS will return the array has a string, so we have to evaluate it before being able to	use it. */
		var strArray = window.external.GetScoresByMinimum(intMinScore);
		return eval(strArray);
	}
	catch (e)
	{
		/* Default. */
		return new Array();
	}
}